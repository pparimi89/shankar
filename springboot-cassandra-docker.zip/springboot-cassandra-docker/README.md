Docker Commands:
---------------------------
stay in current directory in terminal
docker-compose up (will make the cassandra database image up)
docker ps (this will list all the running containers)

--------------------------------------------
//Going to CQLSH.
C:\pradeep\eworkspace\springboot-cassandra-docker>docker ps
CONTAINER ID   IMAGE       COMMAND                  CREATED              STATUS         PORTS                                                       NAMES
aa5b3bf98102   cassandra   "docker-entrypoint.s…"   About a minute ago   Up 7 seconds   7000-7001/tcp, 7199/tcp, 9160/tcp, 0.0.0.0:9042->9042/tcp   mycassandra

C:\pradeep\eworkspace\springboot-cassandra-docker>docker exec -it aa5b3bf98102 bash
root@aa5b3bf98102:/# cqlsh
Connected to Test Cluster at 127.0.0.1:9042
[cqlsh 6.0.0 | Cassandra 4.0.1 | CQL spec 3.4.5 | Native protocol v5]
Use HELP for help.
cqlsh>
--------------------------------------------------
Table creation:
CREATE KEYSPACE mykeyspace
WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 3};

describe keyspaces;(lists all the keyspaces)
use mykeyspace (goes into mykeyspace)

CREATE TABLE Product( id int PRIMARY KEY, name text);
describe tables;(lists all the tables)

-----------------------------------------
now go and run the app(goto SpringbootCassandraDemoApplication -> run main method)




API details.
Add products:
   POST: http://localhost:8080/api/products (application/json)
   {
   "id":"1",
   "name":"Iphone"
   }

Get products:
GET http://localhost:8080/api/products/1

Delete product:







-----------------------------
Added docker file here to start the app from docker.
To build image:
   docker build -f Dockerfile -t springbootcassandrasample .
To run the container:
   docker run -p 8080:8080 springbootcassandrasample

