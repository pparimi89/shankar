package com.example.cassandra.springbootcassandrademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCassandraDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
